<template>
  <div id="bottom">
    <br />
    <hr />
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
    <hr />
    <br />
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
#bottom {
  position: relative;
  bottom: 0%;
}
</style>
