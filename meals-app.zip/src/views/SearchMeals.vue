<template>
  <div id="root">
    <Header />
    <div>
      <h2>SearchMeals</h2>
      <br /><br />
      <ul v-for="(meal, index) in meals.meals" :key="index">
        <li>
          <div class="row">
            <div class="col-sm-5">
              <img :src="meal.strMealThumb" width="45%" /><br />
            </div>
            <div class="col-sm-7">
              <table>
                <tr>
                  <th colspan="2">
                    <h5>
                      <b
                        ><u>{{ meal.strMeal }}</u></b
                      >
                    </h5>
                  </th>
                </tr>
                <tr>
                  <td style="text-align: left">ID:</td>
                  <td style="text-align: left">{{ meal.idMeal }}</td>
                </tr>
                <tr>
                  <td style="text-align: left">Category:</td>
                  <td style="text-align: left">{{ meal.strCategory }}</td>
                </tr>
                <tr>
                  <td style="text-align: left">
                    <button
                      class="btn btn-success"
                      @click="showSelectedMeal(meal.idMeal)"
                    >
                      Search
                    </button>
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </li>
      </ul>
    </div>

    <Footer />
  </div>
</template>
<script>
import { searchMeal } from "../Meals.service";
import Header from "@/components/Header.vue";
import Footer from "@/components/Footer.vue";

export default {
  name: "SearchMeals",
  components: {
    Header,
    Footer
  },
  props: {
    keyword: String
  },
  data() {
    return {
      meals: []
    };
  },
  created() {
    searchMeal(this.keyword).then(response => (this.meals = response.data));
  },
  methods: {
    showSelectedMeal(selectedId) {
      this.$router.push({
        name: "MealDetails",
        params: { mealId: selectedId }
      });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#root {
  height: 100%;
}
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
