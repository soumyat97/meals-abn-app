import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    searchedKey: "",
    selectedMeal: ""
  },
  mutations: {
    searchedKey(state, value) {
      state.searchedKey = value;
    },
    selectedMeal(state, mealId) {
      state.selectedMeal = mealId;
    }
  },
  actions: {},
  modules: {}
});
